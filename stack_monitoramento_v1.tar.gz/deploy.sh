#!/bin/bash
set -e

echo "=========================================================="
echo "      INSTALADOR AUTO-SUFICIENTE - MONITORAMENTO PRO      "
echo "=========================================================="

# 1. Instalar dependências e Docker
echo "--> [1/4] Verificando Docker Engine & Docker Compose..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | bash
fi

# 2. Criar diretórios de trabalho do servidor
echo "--> [2/4] Configurando permissões e diretórios..."
DEST_DIR="/home/nzmservers/monitoring"
mkdir -p "$DEST_DIR/oxidized"

# 3. Copiar arquivos de configuração
echo "--> [3/4] Copiando arquivos de configuração..."
cp files/docker-compose.yml "$DEST_DIR/"
cp files/oxidized/config "$DEST_DIR/oxidized/"
cp files/oxidized/router.db "$DEST_DIR/oxidized/"

chmod -R 777 "$DEST_DIR/oxidized"

# 4. Subir todos os serviços via Docker Compose
echo "--> [4/4] Inicializando os containers..."
cd "$DEST_DIR"
docker compose up -d

echo "=========================================================="
echo "  STACK DE MONITORAMENTO INSTALADA COM SUCESSO!           "
echo "=========================================================="
echo " - Zabbix Web: http://<IP-DO-SERVIDOR>:8080"
echo " - Grafana:    http://<IP-DO-SERVIDOR>:3000 (admin/admin)"
echo " - Oxidized:   http://<IP-DO-SERVIDOR>:8888"
echo "=========================================================="
